-- >>> WamEngine Lua Script File <<<

w = 0
a = 0
s = 0
d = 0

current_x = 0
player_x = 0
player_id = "Player"

x_increment = 5

speed = 10

y_max_offset = 5
function processInput()

	translateObject(player_id, 1*speed*getDeltaTime(), 0, 0) --move to the left

	mouse = getMouse(0)

	if mouse == true then
		applyForce(player_id, 0, 200, 0)
	end

end

function processAdvancement()
	registerPermVar("score", 0)
	registerPermVar("height", -20)
	player_x, player_y, player_z = getObjectPosition(player_id)
	current_x, y, z = getObjectPosition(0)

	if player_x > current_x then
		-- move barriers to the right
		randy = math.random(-y_max_offset, y_max_offset)
		if y > 10 then
			randy = -y_max_offset
		end

		if y < -10 then
			randy = y_max_offset
		end

		print("1")

		height = tonumber(getPermVar("height"))
		height = height + randy
		modifyPermVar("height", height)

		print("2")

		translateObject(0, x_increment, randy, 0)
		translateObject(1, x_increment, randy, 0)
		-- increment current_x
		current_x, y, z = getObjectPosition(0)
		score = tonumber(getPermVar("score"))
		score = score + 1
		modifyPermVar("score", score)

		print(score)
	end


	if player_y < tonumber(getPermVar("height")) or player_y > 0.5 or colliding(player_id, 0) or colliding(player_id, 1) then
		print("YOU DIED!")
		print ("YOUR SCORE IS...")
		print(getPermVar("score"))

		os.exit()
	end


	cam_x, cam_y, cam_z = getCamPos()
	setCamPos(player_x, cam_y, cam_z)

end

function frame()
	processAdvancement()
	processInput()
end
